from app.main import addition

ls = [1,1,2,12]

print(addition(*ls))


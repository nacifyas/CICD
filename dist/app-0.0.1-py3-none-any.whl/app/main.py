import numpy as np

def addition(*args):
    for arg in args:
        v +=  arg
    return np.sin(v)
